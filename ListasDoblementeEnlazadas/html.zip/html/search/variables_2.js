var searchData=
[
  ['previo_0',['previo',['../structNodoCarga.html#aa6af2c76d2a0339094d6edcf3832c3ec',1,'NodoCarga::previo'],['../structNodoRotor.html#a328166e65987458eee4fb15da9ee65c0',1,'NodoRotor::previo']]]
];
