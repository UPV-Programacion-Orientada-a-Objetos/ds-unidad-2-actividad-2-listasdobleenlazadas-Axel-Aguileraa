var searchData=
[
  ['nodocarga_0',['nodocarga',['../structNodoCarga.html',1,'NodoCarga'],['../structNodoCarga.html#a60be300646abda8ce4cc20bfbfd2a91d',1,'NodoCarga::NodoCarga()']]],
  ['nodorotor_1',['nodorotor',['../structNodoRotor.html',1,'NodoRotor'],['../structNodoRotor.html#a3f67e84b40591b779f75e26826fb898d',1,'NodoRotor::NodoRotor()']]]
];
