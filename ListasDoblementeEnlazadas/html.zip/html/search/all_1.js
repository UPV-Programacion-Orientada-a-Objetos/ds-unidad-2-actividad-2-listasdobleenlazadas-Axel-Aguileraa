var searchData=
[
  ['dato_0',['dato',['../structNodoCarga.html#ac82031ee44864bf90a942c1ecb32ffb1',1,'NodoCarga']]]
];
