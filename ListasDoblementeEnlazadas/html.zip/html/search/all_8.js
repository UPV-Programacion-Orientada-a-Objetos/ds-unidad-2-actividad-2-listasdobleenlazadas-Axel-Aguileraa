var searchData=
[
  ['siguiente_0',['siguiente',['../structNodoCarga.html#aa5a7ed9aff1de84311d478b4144e4127',1,'NodoCarga::siguiente'],['../structNodoRotor.html#a66dea829404fd5d2bc80a985f08f263f',1,'NodoRotor::siguiente']]]
];
