var searchData=
[
  ['caracter_0',['caracter',['../structNodoRotor.html#a223a60328e0f9e45a204159bfeccbb9f',1,'NodoRotor']]]
];
